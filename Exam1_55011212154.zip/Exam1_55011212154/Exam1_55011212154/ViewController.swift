//
//  ViewController.swift
//  Exam1_55011212154
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var textName: UITextField!
    @IBOutlet var textTotal: UITextField!
    @IBOutlet var textVol: UITextField!
    @IBOutlet var textPrice: UITextField!
    @IBOutlet var textShow: UITextView!
    
    @IBAction func ViewTap(sender: AnyObject) {
        textTotal.resignFirstResponder()
    }
    
    @IBAction func processProfit(sender: AnyObject) {
       TipC1.vol = Double((textTotal.text as NSString).doubleValue)
        let possibleips = TipC1.returnPossibleTips()
        var results = ""
        
        for(tipPct, tipValue) in possibleips {
            
            results += "ราคาหุ้นขึ้น\(tipPct)%: \(tipValue)\n"
            
        }
        textShow.text = results
    }
    
    let TipC1 = TipC(total: 400, taxPct: 2.32)
    func refreshUI(){
        textTotal.text = String(format: "%0.2f", TipC1.vol)
        
        textShow.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

