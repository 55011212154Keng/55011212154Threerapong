//
//  File.swift
//  Exam1_55011212154
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import Foundation
class calprofit{
    var vol : Double
    var pri : Double
    var subtotal : Double
        {
        get
        {
            return vol * pri
        }
    }
    
    init(vol:Double, pri:Double){
        self.vol = vol
        self.pri = pri
        //subtotal = total / (total+1)
    }
    func calcTipWithTipPct(tipPct:Double)->Double {
        return subtotal * tipPct
    }
    func returnPossibleTips() ->[Int: Double]{
        let possibleTipsInferred = [0.03, 0.05, 1.00]
        let possibleTipsExplicit:[Double] = [0.03, 0.05, 1.00]
        var retval = [Int: Double]()
        for possibleTips in possibleTipsInferred{
            let intPct = Int(possibleTips*100)
            retval[intPct] = calcTipWithTipPct(possibleTips)
        }
        return retval
    }
}